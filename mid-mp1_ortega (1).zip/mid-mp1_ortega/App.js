import React, {useState} from 'react';
import { Button, TextInput, StyleSheet, View, Text, FlatList } from 'react-native';

export default function App () {

  const [enteredGoalText, setEnteredGoalText ] = useState('');

  const [courseGoals, setCourseGoals] = useState([]);

  function goalInputHandler (enteredText) {
    setEnteredGoalText(enteredText);
  }

  function addGoalHandler (){
    setCourseGoals ((currentCourseGoals) => [...currentCourseGoals, {id: Math.random().toString(), value: enteredGoalText, color: getRandomColor()}]);
    setEnteredGoalText('');
  }

  function getRandomColor() {
    let letters = '0123456789ABCDEF';
    let color = '#';
    for (let i = 0; i < 6; i++) {
      color += letters[Math.floor(Math.random() * 16)];
    }
    return color;
  }

  return (
    <View style={styles.appContainer}> 
      <View style= {styles.inputContainer}>
        <TextInput style= {styles.textInput} placeholder='My Goal' onChangeText={goalInputHandler} value={enteredGoalText} /> 
        <Button title="Add Goal" onPress={addGoalHandler} />
      </View>

      <FlatList  
        keyExtractor={(item, index) => item.id} 
        data={courseGoals} 
        renderItem={({ item }) => (
          <View style={[styles.goalsContainer, {backgroundColor: item.color}]}>
            <Text>{'\u2022 ' + item.value}</Text>
          </View>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  appContainer: {
    paddingTop: 50,
    paddingHorizontal: 16,
  },

  inputContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingBottom: 24,
    borderBottomWidth: 1,
  },

  textInput: {
   borderWidth: 1,
   width: '70%',
   marginRight: 8,
   padding: 8,
  },

  goalsContainer: {
    paddingTop: 20,
    margin: 10,
  },
});